# 数学文献调研模板：可复用 Prompt

以下指令配合本项目 ZIP 使用。所有方括号字段均由本次任务自行填写；没有固定的研究方向、论文样例或算法假设。

## 创建新调研

请以我上传的 `Literature_Review_LaTeX_Template.zip` 为格式基础，制作一份英文、公式优先（formula-first）的数学文献调研，并同时交付 `main.tex`、`references.bib`、编译后的 `main.pdf` 和完整项目 ZIP。

**调研信息**

- 主题：`[LITERATURE REVIEW TITLE]`
- 副标题：`[REVIEW SUBTITLE]`
- 作者：`[AUTHOR / RESEARCH GROUP]`
- 更新日期：`[DAY MONTH YEAR]`
- 文献时间范围：`[COVERAGE PERIOD]`
- 核心科学问题：`[CENTRAL RESEARCH QUESTION]`
- 研究范围：`[RESEARCH SCOPE / MODEL CLASS]`
- 重点文献或问题：`[PRIORITY PAPERS / RESEARCH QUESTIONS]`
- 特别希望比较：`[COMPARISON CRITERIA / BASELINES / METRICS]`
- 我提供的资料：`[ATTACHED PAPERS / NOTES / REFERENCES]`

**来源与准确性**

1. 使用能够核对的论文原文与来源链接。不能虚构作者、论文、定理、算法或实验数字；若无法核实，明确写 `unverified`。
2. 以数学问题、假设与理论关系组织内容，避免仅依时间排序。
3. 对每篇重要文献尽量给出实际模型、算法公式或精确定理条件，保留误差指标、复杂度、适用范围与必要限制。
4. 明确区分实验发现、算法设计、证明结论、反例、推测及个人研究计划。
5. 比较论文时明确说明假设、oracle 模型、误差指标、复杂度核算口径和适用场景的差异。
6. 引用必须可以追溯至有效的 DOI、正式论文页面或预印本记录；记录版本和更新情况。

**LaTeX 要求**

1. 基于模板的三部分导言区，替换 PART III 的全部占位符。
2. 保留两栏 `Notation guide`，但按本主题填写真实符号，不沿用模板中的占位类别。
3. 将全部 `[SECTION ...]` 与 `[SUBSECTION ...]` 换成适合本次调研的问题分类，按实际需要增减章节。
4. 使用 `\expentry`、`\methodentry`、`\theoryentry`、`\limitentry` 记录对应类别的论文；不要套用不相关条目类型。
5. 将 `references.bib` 中被注释的空白记录改成已核实的真实文献记录，为每篇论文分配唯一 BibTeX key，并将 `PAPER_KEY_1` 等全部替换。**完成后**将 `\bibliographyreadyfalse` 切换为 `\bibliographyreadytrue`。
6. 完成跨论文比较表、可靠结论、研究机会和核查日志。删除所有 `[PLACEHOLDER]` 和待填项。
7. 编译项目并检查引用、数学符号、溢出、换行和表格；对无法核查的内容显式说明限制。

**交付**：英文正文、可编译的 LaTeX 项目 ZIP 和 PDF，并用中文简要说明调研的核心结论与尚需核实之处。

---

## 更新已有调研

请使用已有的 `[PROJECT NAME]` 文献调研项目，补充截至 `[DAY MONTH YEAR]` 与 `[CENTRAL RESEARCH QUESTION]` 相关的新论文和既有论文修订版。保留经过核实的数学符号、条目命令、BibTeX keys 和分类层次；必要时对新出现的主题调整结构。核对重要更新的原文，准确记录定理条件、算法公式、误差指标、复杂度和版本变化；重新更新比较表、开放问题、核查日志，编译 PDF，交付完整项目 ZIP 和 PDF，并总结相对于上一版的实质变化。
