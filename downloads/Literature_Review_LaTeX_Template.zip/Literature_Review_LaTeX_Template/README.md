# 数学文献调研 LaTeX 空白模板

本项目是可重复使用的 **formula-first mathematical literature review** 模板：保留「统一符号表 → 按主题整理文献 → 单篇公式与假设/结论 → 跨论文比较 → 研究问题与核查记录」的写作结构。模板的排版结构沿用三段式导言区，不预设任何研究课题、论文、年份、公式或实验数据。

**本版本为严格空白模板。** PDF 中方括号内的内容均为待填写字段；`references.bib` 只有被注释的 BibTeX 字段示意，没有任何真实或虚构的论文条目。正式使用前务必完成替换。

## 文件说明

| 文件 | 说明 |
| --- | --- |
| `main.tex` | 主 LaTeX 文件；所有研究内容均为占位符 |
| `references.bib` | 注释状态下的空白 BibTeX 字段模板 |
| `main.pdf` | 可以正常阅读的两页空白模板预览 |
| `README.md` | 当前使用说明 |
| `REUSE_PROMPT.md` | 给 ChatGPT 的通用生成与更新指令 |

## 快速使用

1. 复制项目目录，打开 `main.tex`。
2. 替换 PART III 中的六个元数据字段：`[LITERATURE REVIEW TITLE]`、`[REVIEW SUBTITLE]`、`[AUTHOR / RESEARCH GROUP]`、`[DAY MONTH YEAR]`、`[COVERAGE PERIOD]`、`[CENTRAL RESEARCH QUESTION]`。
3. 填写 `[RESEARCH SCOPE / MODEL CLASS]` 和 `Notation guide`。符号类别、符号名称及解释均不预设；可以增减两栏里的条目。
4. 将 `[SECTION N TITLE]`、`[SUBSECTION N.M TITLE]` 换成实际的分类标题。四种条目分别适配实验报告、算法设计、定理和反例，也可调整次序或删除无关类别。
5. 在 `references.bib` 中复制注释的 BibTeX 记录格式，去掉该记录每一行前面的 `%`，填入核实的文献元数据。给每篇论文一个唯一 key（并同步替换 `main.tex` 中的 `PAPER_KEY_1` 等）。
6. **有真实 BibTeX 记录之后**，把 `main.tex` 里的 `\bibliographyreadyfalse` 改为 `\bibliographyreadytrue`，再进行完整 BibTeX 编译。空白预览时不要切换。
7. 完善比较表、证实的结论、待研究的问题和核查记录。用搜索功能检查是否还存在 `[`、`]`、`PAPER_KEY_` 等占位内容。

## 文献条目命令

这些命令必须放在 `reviewlist` 环境内；所有大括号中的文字是**待填写内容**。

**实验 / 现象**

```latex
\begin{reviewlist}
\expentry{PAPER_KEY_1}
  {\placeholder{MODEL / EVALUATION}}
  {\placeholder{EMPIRICAL FINDING / METRIC}}
  {\placeholder{SYMBOL DEFINITIONS}}
\end{reviewlist}
```

**算法 / 模型**

```latex
\begin{reviewlist}
\methodentry{PAPER_KEY_2}
  {\placeholder{ACTUAL UPDATE EQUATION / MATHEMATICAL MODEL}}
  {\placeholder{DESIGN AND COMPUTATIONAL TRADEOFF}}
  {\placeholder{SYMBOL DEFINITIONS}}
\end{reviewlist}
```

**理论 / 收敛**

```latex
\begin{reviewlist}
\theoryentry{PAPER_KEY_3}
  {\placeholder{ASSUMPTIONS}}
  {\placeholder{PRECISE THEOREM AND ERROR BOUND}}
  {\placeholder{SCOPE AND LIMITATIONS}}
  {\placeholder{SYMBOL DEFINITIONS}}
\end{reviewlist}
```

**反例 / 下界**

```latex
\begin{reviewlist}
\limitentry{PAPER_KEY_4}
  {\placeholder{MATHEMATICAL SETTING}}
  {\placeholder{NEGATIVE RESULT / LOWER BOUND}}
  {\placeholder{SYMBOL DEFINITIONS}}
\end{reviewlist}
```

空白模板中的 `Source` 和比较表的 `Paper` 格都会显示 **[FULL BIBLIOGRAPHIC REFERENCE]** / **[REF]**，以防引用未配置时出现 `?`。切换 `\bibliographyreadytrue` 后，前者调用 `\bibentry{key}`，后者调用 `\citep{key}`，保留原模板的原位完整书目信息机制。

## 编译

只查看空白模板，无需 BibTeX：

```bash
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

正式使用，并填写了 `references.bib` 且已切换 `\bibliographyreadytrue` 后，使用完整的 BibTeX 工具链：

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

也可以在安装了 BibTeX 的 Overleaf / TeX Live 环境使用 `latexmk -pdf main.tex`。

## 数学文献核查原则

- 论文作者、年份、标题、链接和版本必须来自可核实来源。
- 引述数学结论时保留关键假设、精确误差指标、范数、迭代量及适用范围。
- 区分理论定理、实验现象、反例、推测和自己的研究设想。
- 区分 oracle / sample / gradient 调用、迭代步数、计算开销和墙钟时间。
- 相互比较的结果若所处条件或评价指标不同，须明确指出不能直接比较。
- 在 `Verification log` 记录更新日期、已核实的原文及尚未解决的疑问。

更多可复制的生成任务文字见 `REUSE_PROMPT.md`。
