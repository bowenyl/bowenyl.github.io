# 通用英文学术论文 LaTeX 模板

`main.tex` 是可直接编译的英文研究论文 / research note 模板。**正文中的可见内容全部是 `[占位提示]`，不包含任何真实研究实例、定理、算法或文献。**

## 文件

- `main.tex`：完整导言区、双作者署名、标准页码、论文结构及使用示范。
- `references.bib`：含可编译的期刊论文、会议论文、书籍三类**占位** BibTeX 条目，均非真实参考文献。
- `main.pdf`：由占位版源文件编译的预览。

## 编译

在 Overleaf：上传 `main.tex` 和 `references.bib`，选择 **pdfLaTeX**，编译即可；文献交叉引用一般会由 Overleaf 自动执行所需的 BibTeX 步骤。

本地终端（安装 TeX Live/MiKTeX 后）：

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

若手动编译带引文的模板，依次运行 `pdflatex main.tex`、`bibtex main`、`pdflatex main.tex`、`pdflatex main.tex`。

## 导言区结构（本次重排）

`main.tex` 导言区现在分成三个独立部分，顺序是 **先加载宏包与基础配置，再集中定义自己的环境和命令，最后填写单篇论文信息**：

### Part I. Packages and Configuration（基础配置）

1. `Document Class`：文档类。
2. `Page Layout and Typography`：边距、英文排版与字体。
3. `Mathematics Packages`：AMS 数学公式、符号、数学字体及公式编号。
4. `Figures, Tables, and Lists`：图片、子图、表格、列表及 `float` 包。
5. `Algorithms`：`algorithm` 与 `algpseudocode`。
6. `Colors and Graphics`：`xcolor`、`ulem`、TikZ 及常用 TikZ libraries。
7. `Bibliography and Author Packages`：`natbib`、`authblk`。
8. `Other Optional Packages`：可选包（按需启用）。
9. `Hyperlinks and Cross-References`：`hyperref` 后加载 `cleveref`。

### Part II. Custom Definitions（自定义定义）

10. `Theorem-like Environments`：定理、引理、假设、定义、注记等；现在统一放在 `cleveref` 之后定义。
11. `Mathematical Notation and Operators`：`\R`、`\norm{}`、`\argmin` 等数学符号、算子。
12. `Custom Colors and Annotations`：颜色、自定义灰色占位符、草稿批注与修订命令。
13. `Custom TikZ Styles`：自定义节点 `paperbox` 和箭头 `paperarrow`。
14. `Other Custom Commands`：智能交叉引用名称和后续自定义命令。
15. `Page Style`：默认页码与页眉页脚设置。

### Part III. Paper Information（论文信息）

16. `Title`：论文标题。
17. `Authors and Affiliations`：两位作者、单位、通讯作者及日期。
18. `PDF Metadata and Link Appearance`：PDF 标题、作者及链接颜色。PDF 标题直接使用 `\papertitle`，避免与正文标题不一致。

**依赖关系注意事项：** 自定义命令可以集中放在宏包之后；但要确保所需宏包已经加载。`hyperref` 通常在其他常规宏包之后加载，`cleveref` 在 `hyperref` 之后加载，而本模板的 `\newtheorem` 环境定义放在 `cleveref` 之后。若某期刊模板有特殊规定，以期刊说明为准。

## 常用命令与使用方式

| 用途 | 命令 / 环境 | 说明 |
|---|---|---|
| 草稿 / 投稿 | `\drafttrue` / `\draftfalse` | 隐藏 TODO 和删除痕迹；修订内容恢复普通文字；投稿前**仍需清理所有占位内容** |
| 行内批注 | `\todo{TODO TEXT}` | 草稿时显示红色圆括号批注 `(TODO: TODO TEXT)` |
| 修订 | `\revision{[REVISED TEXT]}` | 草稿时显示蓝色，正式版为普通文字 |
| 删除 | `\deleted{(REMOVED TEXT)}` | 草稿时显示删除线，正式版完全消失 |
| 高亮 | `\highlight{[SHORT TEXT]}` | 草稿时黄色背景；正式版恢复为普通文字；建议仅用于短的单行文本 |
| 范数 | `\norm{x}` / `\norm*{...}` | 普通 / 自动伸缩定界符 |
| 内积 | `\inner{u,v}` / `\inner*{...}` | 符号 `\langle\cdot,\cdot\rangle` |
| 自定义环境 | `\begin{theorem}...\end{theorem}` | lemma/definition/assumption/remark 等同理 |
| 证明 | `\begin{proof}...\end{proof}` | 自动添加 QED 符号 |
| 文献 | `\citep{placeholder-article}` / `\citet{placeholder-conference}` | 正文中已经有可编译占位示例，替换 `.bib` 中的数据即可 |
| 交叉引用 | `\cref{thm:placeholder}` | 自动显示类型，如 Theorem、Figure、Algorithm |
| 插图 | `\includegraphics[width=.8\linewidth]{[FILE NAME]}` | 支持 PDF/PNG/JPG；源文件已有注释示范 |
| 浮动体位置 | `[H]` / `[htbp]` | 数值实验表格使用 `[H]` 固定在所属小节内；其他浮动体可按需要改为 `[htbp]` |
| 浮动算法 | `algorithm` + `algorithmic` | 自带 caption/label/Require/Ensure/State/While/If |
| TikZ 绘图 | `tikzpicture` + `paperbox` / `paperarrow` | 标准化图形样式，可自行增添节点和边 |
| 页码 / 页脚 | `\pagestyle{plain}` | 仅保留默认居中页码；若不需要页码可改为 `\pagestyle{empty}` |


## 保留的模板功能（占位与数值试验）

- **红色批注**：`\todo{...}` 的实际显示格式改为 `(TODO: ...)`，不再使用方括号。`\deleted{...}` 的注释示例也改为圆括号；其他灰色论文占位提示保留方括号以便区分。
- **MSC 2020**：在 Keywords 下方加入 `2020 Mathematics Subject Classification`，用 `Primary MSC code; Secondary MSC code(s)` 提示填写分类号，未虚构实际分类号。
- **Numerical Experiments**：新增独立的 `\section{Numerical Experiments}`，包含 `Experimental Setup` 和 `Results and Discussion`，数值表格置于本节，附有注释形式的实验结果图片插入模板。

## 文献引用占位示范

在正文 Introduction 中保留了三种**纯语法示范**（无真实学术内容）：

```latex
\citep{placeholder-article}                   % 方括号中的数字引用
\citet{placeholder-conference}                % 作者名出现在正文的引用
\citep{placeholder-article,placeholder-book}  % 多篇同时引用
```

`references.bib` 中有与这些 key 一一对应的 `@article`、`@inproceedings`、`@book`。所有作者、标题、期刊、年份、页码等字段均是明确的占位提示（含 `20XX`），并非真实文献。以后添加真实文献时直接替换字段和引用 key；删除不需要的示范条目和相应的正文示范语句。

## 页眉页脚

已去掉此前每页重复的短标题、DRAFT 日期和横线，**只保留期刊草稿中常见的页码**。如需彻底隐藏页码，在导言区 Part II 第 15 区将 `\pagestyle{plain}` 改为 `\pagestyle{empty}` 即可。

## 作者设置

在 `main.tex` Part III 第 17 区编辑 `\author[1]`、`\author[2]`、`\affil[1]` 和 `\affil[2]`。

- 两位作者不同单位：保持当前两组 affiliation 编号。
- 同一单位：两位作者均设 `[1]`，删去第二个 `\affil`。
- 更换通讯作者：将 `\thanks{Corresponding author: ...}` 移至相应作者。

## 投稿迁移要点

这个模板默认采用通用 `article` 版式，而不是任何指定期刊的官方版式。期刊若提供 `.cls` / `.sty`，优先用期刊类文件；按期刊要求处理 `geometry`、`authblk`、`natbib`、`algorithm`、`hyperref` 等可能由期刊模板预加载或限制的宏包。

正式投稿前检查：所有 `[PLACEHOLDER]` 和 `\todo` 均已清除，**所有假引文已换成真实文献或删除**，`\draftfalse` 已打开，作者与基金信息真实有效，参考文献条目齐全，文中引用链接完整，并使用期刊指定的参考文献样式。

## 扩展建议

论文正文增长后，可把 Introduction、Main Results、Method、Numerical Experiments 等移入 `sections/*.tex`，在 `main.tex` 使用 `\input{sections/[FILE NAME]}`。符号增长后，可把导言区 Part II 第 11 区移到 `notation.tex` 并 `\input{notation}`。这些拆分只是组织方式，不要求额外宏包。
